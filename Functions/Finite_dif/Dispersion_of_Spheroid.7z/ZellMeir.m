function n = ZellMeir(lambda_0,Const,Material,p,Temp)
%% Describtion
%   lambda_0 -- wavelenght in vacuum
%   Const -- fundamental constants struct
%   Material string value 'Silica' or 'MgO:CLN'
%   p -- string polarization ('TE' or 'TM' input)
%% p states for polarization 

    omega = 2*pi*Const.c/lambda_0;
    
switch Material
    
    case 'Silica'
        
        B_i      = [0.6961663,0.4079426,0.8974794]; 
        lambda_i = [0.0684043,0.1162414,9.896161].*Const.um;
        omega_i  = 2*pi*Const.c./lambda_i;
        nsq      = 1 + sum(B_i.*omega_i.^2./(omega_i.^2-omega.^2));
        n        = sqrt(nsq);
        
    case 'MgO:PPLN'     
        
        lambda_0 = lambda_0*1E6;
        
        switch p
            case 'e' 

                 if (2.7 >= lambda_0) && (lambda_0 >= 0.39)

                    n_e_20 = sqrt(4.54514 + 0.096471./(lambda_0.^2-0.043763) - 0.021502.*lambda_0.^2);

                 elseif (4.95 >= lambda_0) && (lambda_0 > 2.7)
% 
                     n_e_20 =  sqrt(24.6746 + 0.0456./(lambda_0.^2-2.280) + 19166.65./(lambda_0.^2-953.52) + 1.0103./(lambda_0.^2-45.86));
% 
                 end

%                 if 4.95 >= lambda_0 >= 0.4

                    int_der_t_n_e = @(t) ( 0.4175./lambda_0.^3 - 0.6643./lambda_0.^2 + 0.9036./lambda_0 + 3.5332 - 0.0744.*lambda_0)*1E-5*( t + 0.00276*t^2/2 );

%                 end

                n = n_e_20 + int_der_t_n_e(Temp) - int_der_t_n_e(20);
                
            case 'o' 

%                 if 3.7 >= lambda_0 >= 0.5321

                    n_0_20 = sqrt( 19.5542 + 0.11745./(lambda_0.^2 - 0.04557) + 8132.545./(lambda_0.^2 - 554.57) );

%                 end

%                 if 3.7 >= lambda_0 >= 0.424

                    int_der_t_n_o = @(t) ( 0.4519./lambda_0.^4 - 2.1143./lambda_0.^3 + 4.0283./lambda_0.^2 - 2.9264./lambda_0 + 1.0908 ).*1e-5 .* ( t + 0.00216.*t.^2/2 );

%                 end

                n = n_0_20 + int_der_t_n_o(Temp) - int_der_t_n_o(20);                
        end
        lambda_0 = lambda_0*1E-6;
end
end

