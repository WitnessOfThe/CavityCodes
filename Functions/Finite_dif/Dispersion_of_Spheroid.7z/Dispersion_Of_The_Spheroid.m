function Output = Dispersion_Of_The_Spheroid(l_s,r,n,p_str,Const,ind)
%% Describtion
% l_s.zero = start mode
% l_s.range = mode Range l>=10
% r.R big radius r.r - small radius
% n -- zelmeir eq for n,(function handle which return refractive index for input lambda)
% Const -- fundamental constants struct
% p_str -- string polarization ('TE' or 'TM' input)
%% fzero tolerance

    options = optimset('TolX',1E-40);
    
%% Preallocation
    l           =  zeros(1,2*l_s.range);
    lambda_sol  =  zeros(1,2*l_s.range);
    k           = @(lambda)2*pi/lambda;
%omega = k(lambda)*Const.c;
%n     = @(lambda)ZellMeir_Silica(lambda);
%% Spheroid
    R_0 = r.R;
    r_0 = r.r;
    p = ind; %% 
%%
    a_q   = -2.33810741;%-4.08795%-2.33810741;%
 %   a = R_0 + r_0;
 %   b = sqrt((R_0 + r_0)*r_0);
   a = R_0;
   b = sqrt(R_0*r_0);
   
for i = 1:(2*l_s.range)
    
    if p_str == 'TM'
        
        hi = @(lambda)(1./n(lambda)^2);
        l(i) = -l_s.range + i + l_s.zero;
        
        lambda_sol(i)    = fzero(@(lambda)( l(i) - a_q*(l(i)/2)^(1/3) + ( 2*p*( a-b ) + a )/(2*b) - hi(lambda)*n(lambda) / sqrt(n(lambda)^2-1)... 
        + 3*a_q^2/20*(l(i)/2)^(-1/3) - a_q/12*( ( 2*p*(a^3-b^3) + a^3 )/b^3 + 2*n(lambda)*hi(lambda)*(2*hi(lambda)^2-3*n(lambda)^2)/(n(lambda)^2-1)^(3/2))*(l(i)/2)^(-2/3)...
        -n(lambda)*k(lambda)*a),[4000e-9,350e-9],options);
    end
    
    if p_str == 'TE'
        
        hi =@(lambda)1;
        l(i) = -l_s.range+i+l_s.zero;
        
        lambda_sol(i)    = fzero(@(lambda)( l(i) - a_q*(l(i)/2)^(1/3) + ( 2*p*( a-b ) + a )/(2*b) - hi(lambda)*n(lambda) / sqrt(n(lambda)^2-1)... 
        + 3*a_q^2/20*(l(i)/2)^(-1/3) - a_q/12*( ( 2*p*(a^3-b^3) + a^3 )/b^3 + 2*n(lambda)*hi(lambda)*(2*hi(lambda)^2-3*n(lambda)^2)/(n(lambda)^2-1)^(3/2))*(l(i)/2)^(-2/3)...
        -n(lambda)*k(lambda)*a),[4000e-9,350e-9],options);
    end
    
end

    N = size(l,2);
    [dir1,dir2,dir3,dir4,dir5,dir6] = Finite_Derivatives_abs_bound(N);
    
    Output.lambda_0 = lambda_sol;
  %  Output.n_0 = n(lambda_sol);

    Output.omega    = 2*pi./lambda_sol.*Const.c;
    
    Output.l        = l;
    Output.R        = R_0;
    Output.r        = r_0;
    
    Output.omega_1prime = dir1*Output.omega';Output.omega_1prime(1:5) = NaN;Output.omega_1prime(end-5:end) = NaN;
    Output.omega_2prime = dir2*Output.omega';Output.omega_2prime(1:5) = NaN;Output.omega_2prime(end-5:end) = NaN;
    Output.omega_3prime = dir3*Output.omega';Output.omega_3prime(1:5) = NaN;Output.omega_3prime(end-5:end) = NaN;
    Output.omega_4prime = dir4*Output.omega';Output.omega_4prime(1:5) = NaN;Output.omega_4prime(end-5:end) = NaN;
    Output.omega_5prime = dir5*Output.omega';Output.omega_5prime(1:6) = NaN;Output.omega_5prime(end-6:end) = NaN;
    Output.omega_6prime = dir6*Output.omega';Output.omega_6prime(1:6) = NaN;Output.omega_6prime(end-6:end) = NaN;
    
end

