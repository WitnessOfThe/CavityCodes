%% Const
    Const.c  = 299792458;%% meters per second
    Const.h_bar = 1.054*10^-34;
    Const.um = 10^-6;%% micrometers
    Const.e_0 = 8.8541878128*10^-12;
